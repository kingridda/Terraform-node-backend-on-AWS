nginx server:
Load balancer
EC2 (public subnet)
RDS mysql database (2 private subnets)
costumized VPC with 3 subnets 
(on Hold) provisioner is not yet configured to load the .sql script


export PORT, DB_MYSQL_HOST
Still not working :( fuck this shit