import { Test, TestingModule } from '@nestjs/testing';
import { TestRestControllerController } from './test-rest-controller.controller';
import { TestRestControllerService } from './test-rest-controller.service';

describe('TestRestControllerController', () => {
  let controller: TestRestControllerController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [TestRestControllerController],
      providers: [TestRestControllerService],
    }).compile();

    controller = module.get<TestRestControllerController>(TestRestControllerController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
