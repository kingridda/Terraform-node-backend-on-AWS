import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { TestRestController } from './entities/test-rest-controller.entity';

@Injectable()
export class TestRestControllerService {

  constructor(
    @InjectRepository(TestRestController)
    private testRepository: Repository<TestRestController>,
  ) {}

  findAll(): Promise<TestRestController[]> {
    return this.testRepository.find();
  }


}
