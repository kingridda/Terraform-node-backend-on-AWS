import { Module } from '@nestjs/common';
import { TestRestControllerService } from './test-rest-controller.service';
import { TestRestControllerController } from './test-rest-controller.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TestRestController } from './entities/test-rest-controller.entity';

@Module({
  imports: [TypeOrmModule.forFeature([TestRestController])],
  controllers: [TestRestControllerController],
  providers: [TestRestControllerService]
})
export class TestRestControllerModule {}
