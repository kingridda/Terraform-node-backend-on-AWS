import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export class TestRestController {
    
    @PrimaryGeneratedColumn()
    id: number;
    
    @Column()
    title: string;

}
