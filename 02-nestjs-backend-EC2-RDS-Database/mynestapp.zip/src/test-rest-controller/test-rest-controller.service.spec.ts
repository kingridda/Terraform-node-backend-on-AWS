import { Test, TestingModule } from '@nestjs/testing';
import { TestRestControllerService } from './test-rest-controller.service';

describe('TestRestControllerService', () => {
  let service: TestRestControllerService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [TestRestControllerService],
    }).compile();

    service = module.get<TestRestControllerService>(TestRestControllerService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
