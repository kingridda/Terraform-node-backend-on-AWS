import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { TestRestControllerService } from './test-rest-controller.service';


@Controller('test-rest-controller')
export class TestRestControllerController {
  constructor(private readonly testRestControllerService: TestRestControllerService) {}


  @Get()
  findAll() {
    return this.testRestControllerService.findAll();
  }

}
