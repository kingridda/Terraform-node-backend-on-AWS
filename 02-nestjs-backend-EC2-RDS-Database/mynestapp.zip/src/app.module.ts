import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TestRestControllerModule } from './test-rest-controller/test-rest-controller.module';

@Module({
  imports: [
    TestRestControllerModule,
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: (`${process.env.DB_MYSQL_HOST}` || 'localhost' ),
      port: 3306,
      username: 'root',
      password: 'rootrootroot',
      database: 'test_db',
      entities: ["dist/**/*.entity{.ts,.js}"],
      synchronize: true,
    })
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {
}
