import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  getHello(): string {
    return 'Hello World! <a href="/test-rest-controller">test rest API url (exprected output: [])</a>';
  }
}
